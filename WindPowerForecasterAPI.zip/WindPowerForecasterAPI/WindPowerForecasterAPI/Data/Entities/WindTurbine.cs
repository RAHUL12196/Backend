﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace WindPowerForecasterAPI.Data.Entities
{
    public partial class WindTurbine
    {
        public WindTurbine()
        {
            WindPower = new HashSet<WindPower>();
        }

        public int TurbineId { get; set; }
        public decimal Latitude { get; set; }
        public decimal Longitude { get; set; }
        public decimal TurbineRadius { get; set; }
        public bool IsTurbineWorking { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string CompanyId { get; set; }

        public virtual Company Company { get; set; }
        public virtual ICollection<WindPower> WindPower { get; set; }
    }
}
