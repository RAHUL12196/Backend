﻿using GraphQL.Types;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WindPowerForecasterAPI.Data.GraphQL.Types
{
    public class WindPowerInputType : InputObjectGraphType
    {
        public WindPowerInputType()
        {
            Name = "windPowerInputType";
            Field<NonNullGraphType<IntGraphType>>("TurbineId");
            Field<NonNullGraphType<IntGraphType>>("Hour");
            Field<NonNullGraphType<DecimalGraphType>>("WindPower");
        }
    }
}
