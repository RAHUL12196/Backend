﻿using GraphQL.Types;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WindPowerForecasterAPI.Data.Entities;

namespace WindPowerForecasterAPI.Data.GraphQL.Types
{
    public class WindPowerType: ObjectGraphType<WindPower>
    {
        public WindPowerType()
        {
            Field(t => t.TurbineId);
            Field(t => t.Hour);
            Field(t => t.WindPower1);
        }
    }
}
