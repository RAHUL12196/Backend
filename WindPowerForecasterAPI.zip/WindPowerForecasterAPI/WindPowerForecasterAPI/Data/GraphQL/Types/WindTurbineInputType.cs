﻿using GraphQL.Types;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WindPowerForecasterAPI.GraphQL.Types
{
    public class WindTurbineInputType : InputObjectGraphType
    {
        public WindTurbineInputType()
        {
            Name = "windTurbineInputType";
            Field<NonNullGraphType<DecimalGraphType>>("Latitude");
            Field<NonNullGraphType<DecimalGraphType>>("Longitude");
            Field<NonNullGraphType<DecimalGraphType>>("TurbineRadius");
            Field<NonNullGraphType<BooleanGraphType>>("IsTurbineWorking");
            Field<NonNullGraphType<StringGraphType>>("City");
            Field<NonNullGraphType<StringGraphType>>("State");
            Field<NonNullGraphType<StringGraphType>>("CompanyId");
        }
    }
}
