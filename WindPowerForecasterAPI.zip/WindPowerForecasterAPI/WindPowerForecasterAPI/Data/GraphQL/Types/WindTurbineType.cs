﻿using GraphQL.Types;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WindPowerForecasterAPI.Data.Entities;

namespace WindPowerForecasterAPI.GraphQL.Types
{
    public class WindTurbineType : ObjectGraphType<WindTurbine>
    {
        public WindTurbineType()
        {
            Field(windTurbine => windTurbine.TurbineId);
            Field(windTurbine => windTurbine.Latitude);
            Field(windTurbine => windTurbine.Longitude);
            Field(windTurbine => windTurbine.TurbineRadius);
            Field(windTurbine => windTurbine.IsTurbineWorking);
            Field(windTurbine => windTurbine.City);
            Field(windTurbine => windTurbine.State);
            Field(windTurbine => windTurbine.CompanyId);
        }
    }  
    
}
