﻿using GraphQL;
using GraphQL.Types;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WindPowerForecasterAPI.Data.Entities;
using WindPowerForecasterAPI.Data.GraphQL.Types;
using WindPowerForecasterAPI.GraphQL.Types;
using WindPowerForecasterAPI.Repository;

namespace WindPowerForecasterAPI.Data.GraphQL
{
    public class WindPowerForecasterMutation : ObjectGraphType
    {
        public WindPowerForecasterMutation(CompanyRepository companyRepository, UserTableRepository userTableRepository,WindTurbineRepository windTurbineRepository,WindPowerRepository windPowerRepository)
        {
            Field<CompanyType>(
            "addCompany",
            arguments: new QueryArguments(new QueryArgument<NonNullGraphType<CompanyInputType>> { Name = "company" }),
            resolve: context =>
            {
                var company = context.GetArgument<Company>("company");
                return companyRepository.AddCompany(company);
            });

            Field<UserTableType>(
            "addUser",
            arguments: new QueryArguments(new QueryArgument<NonNullGraphType<UserTableInputType>> { Name = "user" }),
            resolve: context =>
            {
                var user = context.GetArgument<UserTable>("user");
                return userTableRepository.AddUser(user);
            });


            Field<WindTurbineType>(
                "addTurbineInfo",
                arguments: new QueryArguments(new QueryArgument<NonNullGraphType<WindTurbineInputType>> { Name = "windTurbine" }),
                resolve: context =>
                {
                    var windTurbine = context.GetArgument<WindTurbine>("windTurbine");
                    return windTurbineRepository.AddWindTurbineInfo(windTurbine);
                }
                );

            Field<WindPowerType>(
            "addWindPower",
            arguments: new QueryArguments(new QueryArgument<NonNullGraphType<WindPowerInputType>> { Name = "windPower" }),
            resolve: context =>
            {
                var windPower = context.GetArgument<WindPower>("windPower");
                return windPowerRepository.AddWindPower(windPower);
            });

            
        }
    }
}
