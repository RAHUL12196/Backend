﻿using GraphQL;
using GraphQL.Types;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WindPowerForecasterAPI.Data.GraphQL.Types;
using WindPowerForecasterAPI.GraphQL.Types;
using WindPowerForecasterAPI.Repository;

namespace WindPowerForecasterAPI.Data.GraphQL
{
    public class WindPowerForecasterQuery : ObjectGraphType
    {
        public WindPowerForecasterQuery(CompanyRepository companyRepository, UserTableRepository userTableRepository,WindTurbineRepository windTurbineRepository, WindPowerRepository windPowerRepository)
        {
            Field<ListGraphType<CompanyType>>(
                "companies",
                resolve: context => companyRepository.GetCompanies()
                );

            Field<ListGraphType<CompanyType>>(
               "companyById",
               arguments: new QueryArguments(new QueryArgument<NonNullGraphType<StringGraphType>> { Name = "companyId" }),
               resolve: context =>
               {
                   var companyId = context.GetArgument<string>("companyId");
                   return companyRepository.GetCompanyByID(companyId);
               });

            Field<ListGraphType<UserTableType>>(
                            "users",
                            resolve: context => userTableRepository.GetUsers()
                            );

            Field<ListGraphType<UserTableType>>(
               "userById",
               arguments: new QueryArguments(new QueryArgument<NonNullGraphType<StringGraphType>> { Name = "userId" }),
               resolve: context =>
               {
                   var userId = context.GetArgument<string>("userId");
                   return userTableRepository.GetUserByID(userId);
               });

            Field<ListGraphType<WindTurbineType>>(
                "windTurbines",
                resolve: context => windTurbineRepository.GetWindTurbineInfo()
                );

            Field<ListGraphType<WindTurbineType>>(
               "turbineByCompanyIdStateCity",
               arguments: new QueryArguments(new QueryArgument<NonNullGraphType<StringGraphType>> { Name = "companyId" }, new QueryArgument<NonNullGraphType<StringGraphType>> { Name = "state" }, new QueryArgument<NonNullGraphType<StringGraphType>> { Name = "city" }),
               resolve: context =>
               {
                   var companyId = context.GetArgument<string>("companyId");
                   var state = context.GetArgument<string>("state");
                   var city = context.GetArgument<string>("city");
                   return windTurbineRepository.GetWindTurbineByCompanyIdStateCity(companyId, state, city);
               });

            Field<ListGraphType<WindPowerType>>(
               "windPowerById",
               arguments: new QueryArguments(new QueryArgument<NonNullGraphType<StringGraphType>> { Name = "turbineId" }),
               resolve: context =>
               {
                   var turbineId = context.GetArgument<int>("turbineId");
                   return windPowerRepository.GetWindPowerByID(turbineId);
               });
        }
    }
}
