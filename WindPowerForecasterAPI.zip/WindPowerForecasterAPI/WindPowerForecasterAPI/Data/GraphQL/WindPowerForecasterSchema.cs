﻿using GraphQL.Types;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WindPowerForecasterAPI.Data.GraphQL
{
    public class WindPowerForecasterSchema : Schema
    {
        public WindPowerForecasterSchema(IServiceProvider resolver) : base(resolver)
        {
            Query = (IObjectGraphType)resolver.GetService(typeof(WindPowerForecasterQuery));
            Mutation = (IObjectGraphType)resolver.GetService(typeof(WindPowerForecasterMutation));
        }
    }
}
