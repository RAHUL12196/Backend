﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WindPowerForecasterAPI.Data.Entities;
using WindPowerForecasterAPI.Data.GraphQL.Types;

namespace WindPowerForecasterAPI.Repository
{
    public class WindPowerRepository
    {
        public WindPowerForecasterDBContext _dbContext;


        public WindPowerRepository(WindPowerForecasterDBContext dbContext)
        {
            _dbContext = dbContext;
        }

        public IEnumerable<WindPower> GetWindPowerByID(int windTurbineID)
        {
            return _dbContext.WindPower.Where(i => i.TurbineId == windTurbineID);
        }
        public WindPower AddWindPower(WindPower windPower)
        {
            _dbContext.WindPower.Add(windPower);
            _dbContext.SaveChanges();
            return windPower;
        }
    }
}
