﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WindPowerForecasterAPI.Data.Entities;

namespace WindPowerForecasterAPI.Repository
{
    public class WindTurbineRepository
    {
        public WindPowerForecasterDBContext _dbContext;

        public WindTurbineRepository(WindPowerForecasterDBContext dbContext)
        {
            _dbContext = dbContext;
        }

        public IEnumerable<WindTurbine> GetWindTurbineInfo()
        {
            return _dbContext.WindTurbine;
        }

        public IEnumerable<WindTurbine> GetWindTurbineByCompanyIdStateCity(string companyId, string city, string state)
        {
            return _dbContext.WindTurbine.Where(i => i.CompanyId == companyId && i.City == city && i.State == state);
        }

        public WindTurbine AddWindTurbineInfo(WindTurbine windTurbine)
        {
            _dbContext.WindTurbine.Add(windTurbine);
            _dbContext.SaveChanges();
            return windTurbine;
        }
    }
}
